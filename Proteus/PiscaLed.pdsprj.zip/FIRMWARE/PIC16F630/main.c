#include <xc.h>

#pragma config FOSC = INTRCCLK  
#pragma config WDTE = OFF       
#pragma config PWRTE = OFF      
#pragma config MCLRE = ON       
#pragma config BOREN = OFF      
#pragma config CP = OFF         
#pragma config CPD = OFF   
#define botao PORTCbits.RC5

#define _XTAL_FREQ 4000000
void main(void) {
    TRISC = 0b000000; 
    PORTC = 0b000001;
    
    while(1){
    PORTC = 0b000001;
    __delay_ms(300);     
      PORTC = 0b000000;
    __delay_ms(300);  
    
   }
}
