#include <xc.h>

#pragma config FOSC = INTRCCLK  
#pragma config WDTE = OFF       
#pragma config PWRTE = OFF      
#pragma config MCLRE = ON       
#pragma config BOREN = OFF      
#pragma config CP = OFF         
#pragma config CPD = OFF   
#define botao PORTCbits.RC5

#define _XTAL_FREQ 4000000
void main(void) {
    TRISC = 0b100000; 
    PORTC = 0b000001;
    char sentido = 1;
    unsigned char led = 0b000001; 
    
    while(1){
    if (botao) {
          sentido = -sentido;  
          __delay_ms(200);    
        }
   if (sentido == 1) {
            led <<= 1;     
            if (led == 0b100000) led = 0b000001; 
   } else {
            led >>= 1;         
            if (led == 0) led = 0b010000; 
   }
    PORTC = led;          
    __delay_ms(300);         
    }
 }

